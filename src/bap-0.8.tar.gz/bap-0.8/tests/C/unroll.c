int main() {
  int i, j;
  int sum = 0;

  for (i = 0; i < 10; i++) {
    for (j = 0; j < 10; j++) {
      sum += 1;
    }
  }

  return sum;
}
