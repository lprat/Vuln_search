(*pp camlp4of *)

(* Left for backward compatibility with existing code that uses pa_openin.
 *
 * For OCaml >= 3.12 this module is no longer needed, since
 * "let open ... in ..." operation is now supported natively.
 *)
