#ifndef __COMMON_H
#define __COMMON_H

#include <stdint.h>

typedef int64_t address_t;

#endif
